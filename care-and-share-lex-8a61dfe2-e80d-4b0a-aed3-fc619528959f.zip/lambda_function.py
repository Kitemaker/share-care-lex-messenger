import json
import os
import logging
import random
import math
import copy
import uuid
import boto3
from decimal import Decimal

######## Convert SSML to Card text ############
from html.parser import HTMLParser
from six import PY2
import helper

class SSMLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.full_str_list = []
        if not PY2:
            self.strict = False
            self.convert_charrefs = True

    def handle_data(self, d):
        self.full_str_list.append(d)

    def get_data(self):
        return ''.join(self.full_str_list)


def convert_html_to_text(html_data):
    # convert ssml speech to text, by removing html tags
    s = SSMLStripper()
    s.feed(html_data)
    return s.get_data()

logger = logging.getLogger()
logger.setLevel(logging.ERROR)
max_question = 5
themes = [];
CONST_SEND_MAIL = False
try:
    with open('themes.json') as f:
        themes = json.load(f)['themes']['theme']
except Exception as ex:
    print('not able to load themes',ex)
    
lang_codes = {'english':'en', 'french':'fr', 'german':'de', 'italian':'it',
              'portugese':'pt', 'russian':'ru', 'spanish':'es', 'turkish':'tr'}
              

GLOBAL_GIVING_URL = "https://www.globalgiving.org/dy/cart/view/gg.html?cmd=addItem&projid={0}&frequency=ONCE&vo=-1&amount={1}"

def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message, response_card):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message,
            'responseCard': response_card
        }
    }


def confirm_intent(session_attributes, intent_name, slots, message, response_card):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ConfirmIntent',
            'intentName': intent_name,
            'slots': slots,
            'message': message,
            'responseCard': response_card
        }
    }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }



def build_theme_response_cards():
    
     
        out_card = list()
        for ln in lang_codes.keys():
            out_card.append({'text':ln,'value':ln})
        return out_card

def build_response_card(title, subtitle, imageUrl="", attachmentLinkUrl = "", options=""):
    """
    Build a responseCard with a title, subtitle, and an optional set of options which should be displayed as buttons.
    attachmentLinkUrl : max length 2048
	imageUrl:2048, 	Subtitl:80, 	title:80, 	buttons:5
    """
    buttons = None
    if options is not None:
        buttons = []
        for i in range(min(5, len(options))):
            buttons.append(options[i])
    
    # return {
    #     'contentType': 'application/vnd.amazonaws.card.generic',
    #     'version': 1,
    #     'genericAttachments': [{
    #         'title': title,
    #         'subTitle': subtitle,
    #         'imageUrl':imageUrl,
    #         'attachmentLinkUrl':attachmentLinkUrl,
    #         'buttons': buttons
    #     }]
    # }
        return {
        'contentType': 'application/vnd.amazonaws.card.generic',
        'version': 1,
        'genericAttachments': [{
            'title': title,
            'subTitle': subtitle,
            'buttons': buttons
        }]
    }
    
def build_project_card(title, subtitle, imageUrl=None, attachmentLinkUrl = "", options=""):
    """
    Build a responseCard with a title, subtitle, and an optional set of options which should be displayed as buttons.
    attachmentLinkUrl : max length 2048
	imageUrl:2048, 	Subtitl:80, 	title:80, 	buttons:5
    """
    buttons = None
    if options is not None:
        buttons = []
        for i in range(min(5, len(options))):
            buttons.append(options[i])
    if imageUrl is None:
        return {
        'contentType': 'application/vnd.amazonaws.card.generic',
        'version': 1,
        'genericAttachments': [{
            'title': title[:80],
            'subTitle': subtitle[:80],
            'buttons': buttons
        }]
        }
    else:
        return {
            'contentType': 'application/vnd.amazonaws.card.generic',
            'version': 1,
            'genericAttachments': [{
                'title': title[:80],
                'subTitle': subtitle[:80],
                'imageUrl':imageUrl,
                'buttons': buttons
            }]
        }
    


def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def try_ex(func):
    """
    Call passed in function in try block. If KeyError is encountered return None.
    This function is intended to be used to safely access dictionary.

    Note that this function would have negative impact on performance.
    """
    try:
        return func()
    except KeyError:
        return None


def get_random_int(minimum, maximum):
    """
    Returns a random integer between min (included) and max (excluded)
    """
    min_int = math.ceil(minimum)
    max_int = math.floor(maximum)

    return random.randint(min_int, max_int - 1)


def build_validation_result(is_valid, violated_slot, message_content, session_attributes):
    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content},
        'session_attributes': session_attributes
    }


def build_options(slot):
    """
    Build a list of potential options for a given slot, to be used in responseCard generation.
    """
    options = []
        
    if slot == 'keyword':
        newtheme = copy.deepcopy(themes)
        for i in [0,1,2,3]:
            th = random.choice(newtheme)
            newtheme.pop(newtheme.index(th))
            options.append({'text':th['name'],'value':th['name']})
        options.append({'text':'Skip','value':'Skip'})
        return options
    if slot == 'xxxxx':
        out_card = list()
        for ln in lang_codes.keys():
            out_card.append({'text':ln,'value':ln})
        return options
    return options

""" --- Functions that control the bot's behavior --- """


def get_numbers(session_attributes):
    matrix = json.loads(session_attributes['matrix'])['data']
    print(matrix)
    index = random.randint(0, len(matrix)-1)
    i = matrix[index][0]
    j = matrix[index][1]
    matrix.pop(index)
    return [i,j,json.dumps({"data":matrix})]


def send_project_to_email(project, email):
    print('send_project_to_email: project = ', project)
    print('send_project_to_email: email = ', email)
    

def validate_find_project_slots(intent_name, session_attributes, intent_request):
    slots = intent_request['currentIntent']['slots']
    slotDetails = intent_request['currentIntent']['slotDetails']
    slot_to_elicit = intent_request.get('slotToElicit', None)
    
        
    if slots['keyword'] in [None, '']:
        return  build_validation_result(False, 'keyword', 'Please enter theme or keyword, some examples are given below. Enter skip to continue', session_attributes)
    
    
    if slots['show_next'] in [None, 'show next', "next", "send email", "Send Email"]:
        # if slots['show_next'] == "donate money" and slots['money'] is None:
        #     return build_validation_result(False, 'money', 'Plesae enter amount', session_attributes)
        # elif slots['show_next'] == "donate money" and slots['money'] is not None:
        #     return build_validation_result(True, None, None, session_attributes)
            
            
        if slots['show_next'] == "send email" and slots['usermail'] is None:
            print('Option-1')
            return build_validation_result(False, 'usermail', 'Plesae enter email', session_attributes)
        elif slots['show_next'] == "send email" and slots['usermail'] is not None:
            print('Option-2')
            
            session_attributes['sendmail'] = 'yes'
            return  build_validation_result(False, 'show_next', 'Sent project details on mail {0}. Enter "Next" to see more projects'.format(slots['usermail']), session_attributes)
        else:
            
            session_attributes['sendmail'] = 'no'
            if intent_name == 'FindFeaturedProject':
                print('Option-3')
                return  build_validation_result(False, 'show_next', 'Featured project details. Enter "Next" to see more projects', session_attributes)
            else:
                print('Option-4')
                return  build_validation_result(False, 'show_next', 'Project for {0}. Enter "Next" to see more images'.format(slots['keyword']), session_attributes)
        
    
    return  build_validation_result(True, None, None, session_attributes)
    
def validate_find_images_slots(intent_name, session_attributes, slots, slotDetails):
    if slots['project_id'] is None:
        print("slots['project_id']" ,slots['project_id'])
        return  build_validation_result(False, 'project_id', 'Please enter project id', session_attributes)
   
        
    if slots['show_next'] in [None, 'show next',""]:
        print("slots['show_next'] = " , slots['show_next'])
        return  build_validation_result(False, 'show_next',
        'Projet images for  project: {0}. Select "Next" to see more images'.format(slots['project_id']),
        session_attributes)
    
    return  build_validation_result(True, None, None, session_attributes)


def find_project(intent_request):
    """
    this method is used as common for intents FindProject and FindFeaturedProject
    """
    intent_name = intent_request['currentIntent']['name']
    slots = intent_request['currentIntent']['slots']
    slotDetails = intent_request['currentIntent']['slotDetails']
    if 'keyword' in slots:
        keyword = slots['keyword']
    else:
        slots['keyword'] = None
    if intent_name == 'FindFeaturedProject':
        slots['keyword'] = 'FEATURED_PROJECT_QUERY'
        
    if 'show_next' in slots:
        show_next = intent_request['currentIntent']['slots']['show_next']
    else:
        slots['show_next'] = None
        
    if 'usermail' in slots:
        usermail = intent_request['currentIntent']['slots']['usermail']
    else:
        slots['usermail'] = None
        
    cards = None
    CONST_SEND_MAIL = False
   
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']
    
    if source == 'DialogCodeHook':
        # try:
        # Perform basic validation on the supplied input slots.
        validation_result = validate_find_project_slots(intent_name, output_session_attributes, intent_request)
        if not validation_result['isValid']:
            if validation_result['violatedSlot'] == 'keyword':
                slots[validation_result['violatedSlot']] = None
                cards = build_response_card('Specify theme enter "Skip" to skip','Select option',options=build_options(validation_result['violatedSlot']))
                return elicit_slot(
                    validation_result['session_attributes'],
                    intent_request['currentIntent']['name'],
                    slots,
                    validation_result['violatedSlot'],
                    validation_result['message'],
                    cards
                    )
        validation_result = validate_find_project_slots(intent_name, output_session_attributes, intent_request)
      
        if not validation_result['isValid'] and validation_result['violatedSlot'] == 'show_next':
            out_proj_request = []
            previous_proj_to_mail = {}
            prj = None
            
            if output_session_attributes.get('userid', None) is None:
                if intent_name == 'FindFeaturedProject':
                    out_proj_request =  helper.get_projects_keyword(slots['keyword'], start=0, featured=True)
                else:
                    out_proj_request =  helper.get_projects_keyword(slots['keyword'], start=0, featured=False)
                userid = str(uuid.uuid4())
                output_session_attributes['userid'] = userid
            else:
                
                read_response_dynamodb = helper.read_project_dynamodb(output_session_attributes['userid'])
                out_proj_request = json.loads(read_response_dynamodb['data'])
                print('out_proj_request')
                
            if len(out_proj_request['projects_list']) > 0:
                try:
                    # if previous command was to send email then first send it 
                    
                    if output_session_attributes.get('sendmail', None) == 'yes':
                        previous_proj_to_mail = json.loads(read_response_dynamodb['previous_project'])
                        print('previous_proj_to_mail', previous_proj_to_mail)
                        send_project_to_email(previous_proj_to_mail, slots['usermail'])
                    
                    prj = out_proj_request['projects_list'].pop(0)
                    # data_to_db = json.loads(json.dumps(out_proj_request, parse_float=Decimal))
                    # json.dump is used because of complext data other wise there will be error in loading data
                    # prj_to_db will be used for sending email
                    
                    data_to_db = json.dumps(out_proj_request)
                    prj_to_db = json.dumps(prj)
                    helper.write_project_dynamodb( output_session_attributes['userid'], {"data":data_to_db, "previous_project":prj_to_db })
                except Exception as ex:
                    print('ERROR while uploading data to DynamoDB', ex)
                output_session_attributes['current_project_id'] = prj['id']
                output_session_attributes['current_project_title'] = prj['title']
                cards = build_project_card(
                    "ID: " + str(prj['id']) + ", " + prj['country'],
                    prj['title'],
                    imageUrl=prj['imageLink'],
                    # attachmentLinkUrl = prj['projectLink'],
                    options =  [{'text':'Next','value':'show next'},
                                # {'text':'Donate','value':'donate money'},
                                {'text':'Send details','value':'send email'}
                    ])
                
                return elicit_slot(
                    output_session_attributes,
                    intent_request['currentIntent']['name'],
                    slots,
                    validation_result['violatedSlot'],
                    validation_result['message'],
                    cards
                    )
            else:
                return elicit_slot(
                    output_session_attributes,
                    intent_request['currentIntent']['name'],
                    slots,
                    validation_result['violatedSlot'],
                    validation_result['message'],
                    None
                    )
                    
        if not validation_result['isValid'] and validation_result['violatedSlot'] == 'usermail':
            print('Entered in usermail elicitslot')
            return elicit_slot(
                    output_session_attributes,
                    intent_request['currentIntent']['name'],
                    slots,
                    validation_result['violatedSlot'],
                    validation_result['message'],
                    None
                    )
        if not validation_result['isValid'] and validation_result['violatedSlot'] == 'money':
            print('Entered in money elicitslot')
            cards = build_project_card(
                    "Project ID: " + str(output_session_attributes['current_project_id']),
                    'Select amount',
                    # attachmentLinkUrl = prj['projectLink'],
                    options =  [{'text':'10', 'value':10},
                                {'text':'20', 'value':20},
                                {'text':'30', 'value':30},
                                 {'text':'50', 'value':50},
                                 {'text':'1000','value':100}
                    ])
            return elicit_slot(
                    output_session_attributes,
                    intent_request['currentIntent']['name'],
                    slots,
                    validation_result['violatedSlot'],
                    validation_result['message'],
                    cards
                    )
            
                
                
                
        # except Exception as ex:
        #     print('Error in DialogCodeHook', ex)
        #     return close(output_session_attributes,
        #     'Fulfilled',
        #     {
        #         'contentType': 'PlainText',
        #         'content': json.dumps("Sorry there is problem in serving your request. Please try again")
        #     })
        return delegate(validation_result['session_attributes'], slots)
    
    
    
    if slots['show_next'] == "donate money" and slots['money'] is not None:
        print('In fulfillment')
        project_id = 44686
        amount = slots['money']
        if output_session_attributes.get('current_project_id', None):
            project_id = output_session_attributes['current_project_id']
        url = GLOBAL_GIVING_URL.format(project_id, amount)
        output_text = "Thank You, Please clink on the link belo to donate: {0}".format(url)
        return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': json.dumps(output_text)
        }
    )
        
        
    
    if output_session_attributes.get('userid', None) is not None:
        # remove unwanted record from dynamodb
        output_session_attributes['userid'] = None
        helper.delete_item_dynamodb(output_session_attributes['userid'])
    output_session_attributes = {}
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': json.dumps("Thanks and good bye!")
        }
    )
    
    
def find_images(intent_request):
    
    slots = intent_request['currentIntent']['slots']
    slotDetails = intent_request['currentIntent']['slotDetails']
    if 'project_id' in slots:
        project_id = slots['project_id']
    else:
        slots['project_id'] = None
        
    if 'show_next' in slots:
        show_next = intent_request['currentIntent']['slots']['show_next']
    else:
        slots['show_next'] = None
   
    cards = None
    source = intent_request['invocationSource']
    output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    intent_name = intent_request['currentIntent']['name']
    
    if source == 'DialogCodeHook':
        print('in the DialogCodeHook')
        try:
            # slots = intent_request['currentIntent']['slots']
            validation_result = validate_find_images_slots(intent_name, output_session_attributes, slots, slotDetails)
            if not validation_result['isValid']:
                slots[validation_result['violatedSlot']] = None
                if validation_result['violatedSlot'] == 'project_id':
                    return elicit_slot(
                        validation_result['session_attributes'],
                        intent_request['currentIntent']['name'],
                        slots,
                        validation_result['violatedSlot'],
                        validation_result['message'],
                        None
                        )
            validation_result = validate_find_images_slots(intent_name, output_session_attributes, slots, slotDetails)
            print('validated show_next')
            if not validation_result['isValid'] and validation_result['violatedSlot'] == 'show_next':
                images = []
            
                if output_session_attributes.get('images', None) is None:
                    images =  helper.get_images('small', slots['project_id'])
                    output_session_attributes['images'] = json.dumps(images)
                else:
                    images = json.loads(output_session_attributes['images'])
                   
                if output_session_attributes.get('project_title', None) is None:
                     project_title = helper.get_specific_project_title(slots['project_id'])
                     output_session_attributes['project_title'] = project_title
                else:
                     project_title = output_session_attributes['project_title']
                    
                print('project_title' ,project_title)
                if len(images) > 0:
                    try:
                        img = images.pop(0)
                        output_session_attributes['images'] = json.dumps(images)
                    except Exception as ex:
                        print('not able to save project.json', ex)
                    cards = build_project_card(
                        project_title,
                        img['title'],
                        imageUrl=img['url'].split(';')[0],
                        options =  [{'text':'Next','value':'show next'}])
                    
                    return elicit_slot(
                        output_session_attributes,
                        intent_request['currentIntent']['name'],
                        slots,
                        validation_result['violatedSlot'],
                        validation_result['message'],
                        cards
                        )
                else:
                    return elicit_slot(
                        output_session_attributes,
                        intent_request['currentIntent']['name'],
                        slots,
                        validation_result['violatedSlot'],
                        validation_result['message'],
                        None
                        )
        except Exception as ex:
            print('Error in DialogCodeHook')
        return delegate(validation_result['session_attributes'], slots)
   
    # source = intent_request['invocationSource']
    # output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}
    # intent_name = intent_request['currentIntent']['name']
    output_session_attributes = {}
    # if images in [None, ""]:
    #     images = ""
    # print('images = ', images)
    return close(
        output_session_attributes,
        'Fulfilled',
        {
            'contentType': 'PlainText',
            'content': json.dumps("Goodbye!")
        }
    )
""" --- Intents --- """

def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    intent_name = intent_request['currentIntent']['name']
        
    if intent_name in ['FindProject', 'FindFeaturedProject']:
        return find_project(intent_request)
        
    if intent_name == 'GetImagesIntent':
        return find_images(intent_request)
        
    raise Exception('Intent with name ' + intent_name + ' not supported')


""" --- Main handler --- """

def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    # logger.debug('event.bot.name={}'.format(event['bot']['name']))
    print('printing event \n {0}',event)
    print('printing context \n {0}',context)
    
    return dispatch(event)