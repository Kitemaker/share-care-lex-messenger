import requests
import boto3
import json
api_key = "ce7b8e5f-6bfa-4b34-ad68-d2e48b46a8ca"
get_theme_url = "https://api.globalgiving.org/api/public/projectservice/themes?api_key=" + api_key

payload = {}
headers = {
  'Accept': 'application/json'
}

def get_themes():
    response = requests.request("GET", get_theme_url, headers=headers, data = payload)
    print(response.text.encode('utf8'))
    for item in response.json()['']:
        print('id : {0}\tname:{1}'.format(item['id'], item['name']))

"""
"""
def get_projects_keyword(keyword, start=0, featured=False):
    headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
    }
    if featured:
        url = "https://api.globalgiving.org/api/public/projectservice/featured/projects"
        payload = {'api_key':api_key}
        response = requests.request("GET", url, headers=headers, params = payload)
        response_data = response.json()
    else:
        themes = [];
        theme_id = None
        try:
            with open('themes.json') as f:
                themes = json.load(f)['themes']['theme']
        except Exception as ex:
            print('not able to load themes',ex)
        for theme in themes:
            if keyword in theme['name']:
                theme_id = theme['id']
                print('Got the theme {0} for keyword {1}'.format(theme_id, keyword))
                break
        if theme_id:
            url = "https://api.globalgiving.org/api/public/projectservice/themes/{0}/projects".format(theme_id)
            payload = {'api_key':api_key}
            response = requests.request("GET", url, headers=headers, params = payload)
            response_data = response.json()
        else:
            print('Did not find theme')
            url = "https://api.globalgiving.org/api/public/services/search/projects/summary"
            payload = {'q': keyword, 'api_key':api_key, 'start':start}
            response = requests.request("GET", url, headers=headers, params = payload)
            request_data = response.json()['search']['request']
            response_data = response.json()['search']['response']
            # print('number found:{0} start: {1}'.format(response_data['numberFound'], response_data['start']))
    output = []
   
    return {"start":start, "projects_list":response_data['projects']['project'] }
    
    

    
def write_project_dynamodb(userid, project_data):
    dynamodb = boto3.resource('dynamodb')
    print('writing for userid {0}'.format(userid), project_data)
    table = dynamodb.Table('CareAndShare')
    response = table.put_item(
       Item={
            'userid':userid,           
            'project_data': project_data
        }
    )
    print('write response = ', response)
    return response
    
def read_project_dynamodb(userid):
    print('reading for userid {0}'.format(userid))
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('CareAndShare')
    response = table.get_item(Key={'userid': userid})
    print('read response= ', response)
    return response['Item']['project_data']

def delete_item_dynamodb(userid):
    print('deleting for userid {0}'.format(userid))
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('CareAndShare')
    response = table.delete_item(Key={'userid': userid})
    print('delete response = ', response)
    return response
    
    
def get_images(size, projectid):
    
    url = "https://api.globalgiving.org/api/public/projectservice/projects/4381/imagegallery?api_key=ce7b8e5f-6bfa-4b34-ad68-d2e48b46a8ca"
    payload = {'api_key':api_key}
    headers = {
    'Accept': 'application/json'
    }
    images = []
    try:
        response = requests.request("GET", url, headers=headers, params = payload)
        print('response = ', response)
        response_data = response.json()['images']['image']
     
        for im in response_data:
            for link in im['imagelink']:
                if link['size'] == size:
                    images.append({'title' : im['title'] , 'url': link['url']})
                    
    except Exception as ex:
        print('get_images: Error while getting images: ', ex)
        
  
    return images

def get_specific_project_title(pid):
    try:
        url = "https://api.globalgiving.org/api/public/projectservice/projects/" + str(pid)
        payload = { 'api_key':api_key}
        headers = {
       
        'Accept': 'application/json'
        }
        response = requests.request("GET", url, headers=headers, params = payload)
        project = response.json()['project']
        project_title = project['title']
        print(project)
        return project_title
    except Exception as ex:
        print('get_specific_project: Error while getting project: ', ex)
        return ""
    
    